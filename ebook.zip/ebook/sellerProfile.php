<!DOCTYPE html>
<head>
    <title>Seller dashboard</title>
    <link rel="stylesheet" href="seller.css">
</head>
<body>

    <div class="navbar">

        <a href="#" class="logo">eBook</a>
        
        <div class="dropdown-container">
        <a href="#">Contact Us</a>
            
            <div class="dropdown-content">
                <a href="http://www.facebook.com">Facebook</a>
                <a href="http://www.twitter.com">Twitter</a>
                <a href="http://www.gmail.com">Email</a>
        
            </div>
        </div>
        <div class="dropdown-container">
        <a href="#">LogOut</a>
            
            
        </div>
        </div>


    <h2 class="one">Welcome to seller dashboard. Here you can upload
        and edit your books.
    </h2>
    <p class="two">Your current books</p>
    <table class="t-one">
        <tr>
            <th>
                <img src="AI.jpg" alt="AI image"><br>
                <lable class="lo">Artificial Inteligence</lable><br>
                <button class="button" type="button">Edit</button>
            </th>
            <th>
                <img src="Csharp.png" alt="Csharp image"><br>
                <lable class="lo">C#</lable><br>
                <button class="button" type="button">Edit</button>
            </th>
            <th>
                <img src="C++.jpg" alt="C++ image"><br>
                <lable class="lo">C++</lable><br>
                <button class="button" type="button">Edit</button>
            </th>
            <th>
                <img src="java.png" alt="Java image"><br>
                <lable class="lo">Java</lable><br>
                <button class="button" type="button">Edit</button>
            </th>
        </tr>
    </table>
    <br>
    <lable class="two">Upload a new book</lable>
    <button class="button" type="button">Upload new book...</button>
    <br><br>
    <label class="two">View sales history</lable>
    <button class="button" type="button">Sales</button>
    <br><br>
</body>
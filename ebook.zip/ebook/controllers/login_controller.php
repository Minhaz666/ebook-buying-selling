<?php
session_start();
    include 'models/db_config.php';
	
	$name="";
    $err_name="";
    
    $username="";
    $err_username="";
	
    $password="";
    $err_password="";
	
	$dob="";
	$err_dob="";
	
	$bGroup="";
	$err_bGroup="";
	
	$email="";
	$err_email="";
	
	$phone="";
	$err_phone="";
	
	$department="";
	$err_department="";
	
	$hospital="";
	$err_hospital="";
	
	$usertype="";
	$err_usertype="";
	
	$date="";
	$err_date="";
	
	$time="";
	$err_time="";
	
	$pname="";
	$err_pname="";
	
	$nopatient="";
	$err_nopatient="";

    $err_db="";	

    $hasError=false;
	$array= array("A+","A-","B+","B-","AB+","AB-","O+","O-");
	$arrayUser= array("Admin","Seller","Customer");

    
    if (isset($_POST["login"])){
		if(empty($_POST["usertype"])){
            $hasError=true;
            $err_usertype="Type Required";
        }
        else{
            $usertype=$_POST["usertype"];
        }
        if(empty($_POST["username"])){
            $hasError=true;
            $err_username="User Name Required";
        }
        else{
            $username=$_POST["username"];
        }

        if(empty($_POST["password"])){
            $hasError=true;
            $err_password="Password Required";
        }
        else{
            $password=$_POST["password"];
        }

        if(!$hasError){
			if($usertype=="Admin"){
				if(authenticateUserAdmin($username,$password)){
					$_SESSION["loggedAdmin"] = $_POST["username"];					
			header("Location: adminProfile.php");
		    }
		    $err_db="Username password invalid";
		    }


			else if($usertype=="Seller"){
				if(authenticateUserSeller($username,$password)){
					$_SESSION["loggedseller"] = $_POST["username"];					
			header("Location: sellerProfile.php");
		    }
		    $err_db="Username password invalid";
		    }



			else if($usertype=="Customer"){
				if(authenticateUserCustomer($username,$password)){
					$_SESSION["Customer"] = $_POST["username"];					
			header("Location: customerProfile.php");
		    }
		    $err_db="Username password invalid";
		    }



		}
	}
	
 else if(isset($_POST["accept"])){
		$id=$_POST["id"];
		sellerAccept($id);
        header("Location: sellerRequest.php");
 }
 else if(isset($_POST["reject"])){
		$id=$_POST["id"];
		sellerReject($id);
        header("Location: sellerRequest.php");
 }
	
 else if(isset($_POST["deleteseller"])){
		$id=$_POST["id"];
		sellerDelete($id);
        header("Location: allSellerList.php");
 }
	
	
	
	//All Functions
	
	
	
	

	function authenticateUserAdmin($username,$password){
		$query="select * from admin where username='$username' and password='$password'";
		$rs=get($query);
		if(count($rs)>0){
			return true;
		}
		return false;
	}

	function authenticateUserSeller($username,$password){
		$query="select * from finalseller where username='$username' and password='$password'";
		$rs=get($query);
		if(count($rs)>0){
			return true;
		}
		return false;
	}

	function authenticateUserCustomer($username,$password){
		$query="select * from customer where username='$username' and password='$password'";
		$rs=get($query);
		if(count($rs)>0){
			return true;
		}
		return false;
	}
	function getAllSeller(){
		$query= "select * from seller";
		$rs= get($query);
		return $rs;
	}
	function getSellerById($id){
     $query="select * from seller where id=$id";
     $rs=get($query);
     return $rs;
    }
	function getAdminByUsername($username){
		$query= "select * from admin where username='$username'";
		$rs= get($query);
		return $rs;
	}
	
	function sellerAccept($id){
        $query1="select * from seller where id='$id'";
        $result=get($query1);
        foreach ($result as $row){ 
            //$id =$row['id'];
            $name =$row['name'];
            $username =$row['username'];
            $password =$row['password'];
            $dob =$row['dob'];
            $bGroup =$row['bGroup'];
            $email =$row['email'];
            $phone =$row['phone'];
          }
		 $query2="INSERT INTO `finalseller` (`id`, `name`, `username`, `password`, `dob`, `bGroup`, `email`, `phone`) VALUES (NULL, '$name', '$username', '$password', '$dob', '$bGroup', '$email', '$phone')"; 
		 execute($query2);
		 
		 $query3="delete from seller where id=$id";
		 execute($query3);
    }
	function sellerReject($id){
		$query="delete from seller where id=$id";
		$rs= get($query);
		return $rs[0];
	}
	function getSellerList(){
		$query= "select id,name,dob,bGroup,email,phone from finalseller";
		$rs= get($query);
		return $rs;
	}
	function getCustomerList(){
		$query= "select id,name,dob,bGroup,email,phone from customer";
		$rs= get($query);
		return $rs;
	}
	function getFinalSellerById($id){
     $query="select * from finalseller where id=$id";
     $rs=get($query);
     return $rs;
    }
	function sellerDelete($id){
		$query="delete from finalseller where id=$id";
		$rs= get($query);
		return $rs[0];
	}
	
?>




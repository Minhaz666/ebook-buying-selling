<?php
$token = "";
$token2 ="";
session_start();
if(isset($_SESSION["uname"])){
    $token ="\eBook\Session\Signout.php";
    $token2 = "Sign Out";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <title>ebook |Admin Dashboard</title> 
</head>
<body>
  <label>Admin Dashboard</label>
</body>

</html>
<?php
if(session_status() >= 0){
    session_status();
    if(isset($_SESSION["uname"])){
        header("refresh: 1; url = homepage.php" );
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <link rel="stylesheet" href="/eBook/Css/homepage.css">
</head>
<body>


    <!-- Navbar -->
    <div class="navbar">

<a href="#" class="logo">eBook</a>

<div class="dropdown-container">
<a href="#">Contact Us</a>
    
    <div class="dropdown-content">
        <a href="http://www.facebook.com">Facebook</a>
        <a href="http://www.twitter.com">Twitter</a>
        <a href="http://www.gmail.com">Email</a>

    </div>
</div>
<div class="dropdown-container">
<a href="#">LogIn/SignUp</a>
    
    <div class="dropdown-content">
        <a href="Loginpage.php">Login</a>
        <a href="Registrationpage.php">Registration</a>
    </div>
</div>
</div>

<!-- Home Screen Grid -->

<div class="grid-container"> 
                    <table>
                        <tr>
                            <td><a href= "#"><img src="\eBook\Files\AI.jpg"  width="300" hight = "300"></td>
                            <td><a href= "#"><img src="\eBook\Files\Csharp.png"  width="300" hight = "300"></td>
                            <td><a href= "#"><img src="\eBook\Files\C++.jpg"  width="300" hight = "300"></td>
                            <td><a href= "#"><img src="\eBook\Files\DM.png"  width="300" hight = "300"></td>
                            <td><a href= "#"><img src="\eBook\Files\java.png"  width="300" hight = "300"></td>
                        </tr> 
                        <tr> 
                            <td><h2 ><a href= "#">Artificial Intelligence</h2></td>
                            <td><h2 ><a href= "#">C shearp</h2></td>
                            <td><h2 ><a href= "#">C ++</h2></td>
                            <td><h2 ><a href= "#">Discrete Mathmetics</h2></td>
                            <td><h2 ><a href= "#">java</h2></td>
                        </tr>
                    </table>    
     </div>

     <!-- Footer -->
     <footer class="footer" id="footer">
            <p>  
                <h1>Ebook center</h1>
                <h3 >ADDRESS: MOTIJIL DHAKA</h3>
                <h3 >EMAIL: EBOOK@GMAIL.COM</h3>
                <h3 >PHONE NUMBER: 0123324809230</h3>
                <h3 >CLICK AND ENJOY BECAUSE EVERYTHING NOW IS IN YOUR HAND. YOU DON'T HAVE TO WASTE YOUR VALUEABLE TIME FOR THIS</h3>
                <h3 >BECAUSE WE ARE HERE FOR YOU. HERE YOU CAN FIND THE GENUINE books HERE.</h3><br>
                <h3 class="website"><a href="#">ebook.com</a></h3>
            </p>
    </footer>


</body>
</html>
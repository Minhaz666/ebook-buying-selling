<?php

?>
<!DOCTYPE html>
<html lang = "en">
<head>
        <title>ebook | Signup</title>
        <link rel="stylesheet" href="/ebook/Css/registration.css">
</head>
    <body>
        
        <table class="center">
            <tr><td><h1>Registration</h1></td></tr>
            <tr><td><form action="\Session\Signup.php" method="post"></td></tr>
            <tr><td><input type="text" name="fname" id="fname" placeholder="First name" required></td></tr>
            <tr><td><input type="text" name="mname" id="mname" placeholder="Middle name" required></td></tr>
            <tr><td><input type="text" name="lname" id="lname" placeholder="last name" required></td></tr>
            <tr><td><label for="birthday">Birthday:</label></td></tr>
            <tr><td><input type="date" id="birthday" name="birthday" required></td></tr>
            <tr><td><input type="email" id="email" name="email" placeholder="email" required></td></tr>
            <tr><td><input type="tel" id="phone" name="phone" placeholder="phone-number" required></td></tr>
            <tr><td><input type="text" id="username" name="uname" placeholder="user-name" required></td></tr>
            <tr><td><input type="password" id="pwd" name="pass" placeholder="password" required></td></tr>
            <tr><td><input type="password" id="cpwd" name="cpass" placeholder="Confirm-password" required></td></tr>
            <tr><td><input type="submit" name="submit"> 
            <tr><td>OR</td></tr>
            <tr><td><h2 class="item-title"><a href= "Loginpage.php">Login</h2></td></tr>
            </form>
              </table> 
    </section>
       
    </body>
</html> 
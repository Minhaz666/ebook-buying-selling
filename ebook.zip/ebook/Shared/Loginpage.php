<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ebook | Login</title>
    <link rel="stylesheet" href="/eBook/Css/login.css">
</head>
<body>
<div style="text-align:center" class="form-conteinar">
    <form action="/eBook/Session/Signin.php" method="POST" class="form">
        <h1>Log In</h1>
        <table>
            <tr>
                <td><label for="email" class="input-text">Username:</label> </td>
                <td> <input type="text" name="uname" id="email" class="input" required></td>
                <span id="err-pass" ></span></td>
            </tr>
            <tr>
                <td><label for="password" class="input-text">Password:</label></td>
                <td><input type="password" name="pass" id="password" class="input" required></td>
                <span id="err-pass" ></span></td>
            </tr>
        </table>
        <div class="button"><button type="submit" class="btn">Log In</button></div>
       <div class="button"><button type="reset" class="btn">Reset</button></div> 
        <div class="text"> Don't Have an Account?<a href="Registrationpage.php"> Register</a></div>
    </form>
</div>    
</body>
</html>